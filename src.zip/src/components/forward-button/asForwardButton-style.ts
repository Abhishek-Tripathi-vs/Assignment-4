import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    mainContainer:{
        flex:1,
    },
    buttons:{
        height:20,
        width:20,
        marginHorizontal:50,
      }
})